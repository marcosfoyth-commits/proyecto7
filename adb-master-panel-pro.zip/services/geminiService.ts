
import { GoogleGenAI, Type } from "@google/genai";
import { ADBConfig, AIResponse } from "../types";

// Corrected initialization to use process.env.API_KEY directly
const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const explainScript = async (config: ADBConfig, scriptContent: string): Promise<AIResponse> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `
      Explain the following ADB connection script for an IP of ${config.ip} and port ${config.port}.
      Provide a brief explanation of what it does and 3-5 troubleshooting tips if the connection fails.
      
      Script Content:
      \`\`\`
      ${scriptContent}
      \`\`\`
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          explanation: { type: Type.STRING },
          tips: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["explanation", "tips"]
      }
    }
  });

  try {
    // response.text is a property, use it directly
    return JSON.parse(response.text || '{}') as AIResponse;
  } catch (e) {
    return {
      explanation: "Could not generate AI explanation.",
      tips: ["Ensure ADB is installed", "Check network connection", "Enable USB debugging"]
    };
  }
};
